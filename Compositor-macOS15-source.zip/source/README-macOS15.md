# Compositor macOS 15 社区适配版

这是基于 Robbie Tilton 的 [Compositor](https://github.com/robbietilton/Compositor) 源码制作的非官方适配版，保留原项目的 MIT 许可证（见 LICENSE）。目标为 Apple Silicon（arm64）及 macOS 15，使用 Xcode 16.2 构建。不是原作者提供或支持的发行版。

源码包含针对 Swift 旧编译器、主线程隔离和 macOS 15 SDK 的兼容性修改。RAW 高光恢复功能在此适配版暂不可用。仅验证应用启动、新建 1920 × 1080 画布和图层；其他功能尚未全面测试。原项目的自动更新可能提供仅支持新系统的版本，请勿将其用于覆盖此适配版。

## 构建

在安装了 Xcode 16.2 的 Mac 上执行：

```sh
xcodebuild -project Compositor.xcodeproj -scheme Compositor -configuration Debug -destination 'platform=macOS,arch=arm64' -derivedDataPath build CODE_SIGNING_ALLOWED=NO build
codesign --force --deep --sign - build/Build/Products/Debug/Compositor.app
```

首次构建需要联网获取 Sparkle 依赖。上述签名仅用于本机测试，并非 Apple Developer ID 签名或公证，其他 Mac 上可能无法直接打开。未经验证的自动更新和发布脚本不能用于发布此适配版。

GitHub 可保存源代码；安装包是构建产物，需单独上传为 Release 附件（不能只依赖源码仓库自动生成）。上传前请确认仓库可见性以及不包含私密信息。
