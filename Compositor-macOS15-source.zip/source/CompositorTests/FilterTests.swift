import AppKit
import Testing
@testable import Compositor

@MainActor
struct FilterTests {
    @Test func gaussianBlurSoftensAHardEdgeAndSpreadsPastTheLayerEdgeAsOneUndoStep() async throws {
        let session = EditorSession()
        // Room on every side of the layer: at the canvas's edge a blur carries the layer on instead (see below).
        session.createDocument(width: 80, height: 60)
        // Left half opaque white, right half transparent.
        let context = try BrushRaster.context(width: 40, height: 20, mask: false)
        context.setFillColor(CGColor(srgbRed: 1, green: 1, blue: 1, alpha: 1))
        context.fill(CGRect(x: 0, y: 0, width: 20, height: 20))
        let image = try #require(context.makeImage())
        session.insert(ImportedImage(image: image, thumbnail: image, name: "Half"))
        let before = try #require(session.activeLayer?.transform.origin)
        session.beginFilter(.gaussianBlur)
        #expect(session.filterEdit != nil && !session.canEditLayers)
        session.updateFilter(FilterSettings(radius: 3), preview: true)
        let count = session.history.undoCount
        await session.commitFilter()
        #expect(session.filterEdit == nil && session.history.undoCount == count + 1)
        #expect(session.filterSettings.radius == 3)
        let result = try #require(session.activeLayer?.asset?.image)
        let pixels = try #require(CGContext(data: nil, width: result.width, height: result.height, bitsPerComponent: 8,
            bytesPerRow: result.width * 4, space: CGColorSpace(name: CGColorSpace.sRGB)!,
            bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue | CGBitmapInfo.byteOrder32Big.rawValue))
        pixels.draw(result, in: CGRect(x: 0, y: 0, width: result.width, height: result.height))
        let bytes = try #require(pixels.data).assumingMemoryBound(to: UInt8.self)
        // The blur is not clamped at the layer's edge: the layer is given room, the blur spreads into it and
        // whatever stays empty is cut away again (Filters.swift, `growForBlur` / `PixelFilter.trimmed`). The
        // 40 x 20 layer, opaque across its full height for its left half, comes out 36 x 36, 8 px up and left. This
        // used to read three fixed columns of a 40-wide result and assert that the border did not fade, from
        // when the blur smeared outwards and stopped at the edge; the test's name said so too.
        let origin = try #require(session.activeLayer?.transform.origin)
        #expect(origin.x < before.x && origin.y < before.y, "the layer grew on every side: origin \(origin)")
        // The strongest evidence that the blur left the layer: it was 20 tall and opaque top to bottom, so it
        // could not have grown vertically unless the blur went past the edge and the layer was given room.
        #expect(result.height > 20, "the blur spread past the layer's edge: height \(result.height)")
        #expect(result.width < 40, "and the half that stayed empty was trimmed away: width \(result.width)")
        let middle = (0..<result.width).map { Int(bytes[(result.height / 2 * result.width + $0) * 4 + 3]) }
        // 250 rather than 255: the block's centre is 10 px from its edges, which at this radius leaves it a
        // fraction of a level below full opacity. What would break here is the inside fading, not rounding.
        #expect(try #require(middle.max()) >= 250, "the block's inside is untouched: \(middle.max() ?? -1)")
        #expect(middle.contains { $0 > 20 && $0 < 235 }, "the hard edge is now soft")
        #expect(try #require(middle.last) < 20, "and it fades out on the far side")
    }

    /// Preserve Transparency blurs only the colors: the layer keeps its size and every pixel its alpha, and the colors
    /// next to the clear part are the layer's own, not darkened by the clear pixels beside them.
    @Test func gaussianBlurCanPreserveTransparency() async throws {
        let session = EditorSession()
        session.createDocument(width: 40, height: 20)
        // Red, then green, across the left half; the right half clear.
        let context = try BrushRaster.context(width: 40, height: 20, mask: false)
        context.setFillColor(CGColor(srgbRed: 1, green: 0, blue: 0, alpha: 1))
        context.fill(CGRect(x: 0, y: 0, width: 10, height: 20))
        context.setFillColor(CGColor(srgbRed: 0, green: 1, blue: 0, alpha: 1))
        context.fill(CGRect(x: 10, y: 0, width: 10, height: 20))
        let image = try #require(context.makeImage())
        session.insert(ImportedImage(image: image, thumbnail: image, name: "Halves"))
        let transform = try #require(session.activeLayer?.transform)
        session.beginFilter(.gaussianBlur)
        var settings = FilterSettings(radius: 3)
        settings.preserveTransparency = true
        session.updateFilter(settings, preview: true)
        await session.commitFilter()
        #expect(session.activeLayer?.transform == transform, "the layer didn't grow or move")
        let result = try #require(session.activeLayer?.asset?.image)
        #expect(result.width == 40 && result.height == 20)
        let pixels = try #require(CGContext(data: nil, width: 40, height: 20, bitsPerComponent: 8, bytesPerRow: 160,
            space: CGColorSpace(name: CGColorSpace.sRGB)!,
            bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue | CGBitmapInfo.byteOrder32Big.rawValue))
        pixels.draw(result, in: CGRect(x: 0, y: 0, width: 40, height: 20))
        let bytes = try #require(pixels.data).assumingMemoryBound(to: UInt8.self)
        func pixel(_ x: Int, _ y: Int) -> [Int] { (0..<4).map { Int(bytes[(y * 40 + x) * 4 + $0]) } }
        let alphas = (0..<20).flatMap { y in (0..<40).map { x in pixel(x, y)[3] } }
        #expect(alphas == (0..<20).flatMap { _ in (0..<40).map { $0 < 20 ? 255 : 0 } }, "every pixel kept its alpha")
        let edge = pixel(19, 10)
        #expect(edge[1] >= 250 && edge[0] <= 5, "green to the very edge, not darkened: \(edge)")
        let seam = pixel(9, 10)
        #expect(seam[0] > 60 && seam[1] > 60, "red and green blur into each other: \(seam)")
    }

    /// Through a selection, the preserved blur lands where the selection is: the layer isn't padded for it, so the
    /// selection is read against the layer as it is.
    @Test func preservedBlurStaysInsideTheSelection() async throws {
        let session = EditorSession()
        session.createDocument(width: 40, height: 20)
        let context = try BrushRaster.context(width: 40, height: 20, mask: false)
        context.setFillColor(CGColor(srgbRed: 1, green: 0, blue: 0, alpha: 1))
        context.fill(CGRect(x: 0, y: 0, width: 10, height: 20))
        context.setFillColor(CGColor(srgbRed: 0, green: 1, blue: 0, alpha: 1))
        context.fill(CGRect(x: 10, y: 0, width: 10, height: 20))
        let image = try #require(context.makeImage())
        session.insert(ImportedImage(image: image, thumbnail: image, name: "Halves"))
        // The green block only.
        session.setSelection(DocumentSelection(path: CGPath(rect: CGRect(x: 10, y: 0, width: 10, height: 20), transform: nil),
                                               antialiased: false, feather: 0), name: "Green")
        session.beginFilter(.gaussianBlur)
        var settings = FilterSettings(radius: 3)
        settings.preserveTransparency = true
        session.updateFilter(settings, preview: true)
        await session.commitFilter()
        let result = try #require(session.activeLayer?.asset?.image)
        let pixels = try #require(CGContext(data: nil, width: 40, height: 20, bitsPerComponent: 8, bytesPerRow: 160,
            space: CGColorSpace(name: CGColorSpace.sRGB)!,
            bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue | CGBitmapInfo.byteOrder32Big.rawValue))
        pixels.draw(result, in: CGRect(x: 0, y: 0, width: 40, height: 20))
        let bytes = try #require(pixels.data).assumingMemoryBound(to: UInt8.self)
        func pixel(_ x: Int) -> [Int] { (0..<4).map { Int(bytes[(10 * 40 + x) * 4 + $0]) } }
        #expect(pixel(9)[0] >= 250 && pixel(9)[1] <= 5, "the red outside the selection is untouched: \(pixel(9))")
        #expect(pixel(10)[0] > 30, "the green just inside it picks up the red beside it: \(pixel(10))")
    }

    /// At the canvas's edge a blur carries the layer's edge pixels on, as Photoshop's does: a picture filling the canvas
    /// keeps solid edges and its size, and only what's inside it blurs.
    @Test func blurKeepsAPictureFillingTheCanvasSolidAtItsEdges() async throws {
        let session = EditorSession()
        session.createDocument(width: 40, height: 20)
        let context = try BrushRaster.context(width: 40, height: 20, mask: false)
        context.setFillColor(CGColor(srgbRed: 1, green: 0, blue: 0, alpha: 1))
        context.fill(CGRect(x: 0, y: 0, width: 20, height: 20))
        context.setFillColor(CGColor(srgbRed: 0, green: 1, blue: 0, alpha: 1))
        context.fill(CGRect(x: 20, y: 0, width: 20, height: 20))
        let image = try #require(context.makeImage())
        session.insert(ImportedImage(image: image, thumbnail: image, name: "Picture"))
        let transform = try #require(session.activeLayer?.transform)
        for kind in [FilterKind.gaussianBlur, .motionBlur] {
            session.beginFilter(kind)
            session.updateFilter(FilterSettings(radius: 4, distance: 30), preview: true)
            await session.commitFilter()
            #expect(session.activeLayer?.transform == transform, "\(kind.rawValue): the layer kept its place and size")
            let result = try #require(session.activeLayer?.asset?.image)
            let pixels = try #require(CGContext(data: nil, width: 40, height: 20, bitsPerComponent: 8, bytesPerRow: 160,
                space: CGColorSpace(name: CGColorSpace.sRGB)!,
                bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue | CGBitmapInfo.byteOrder32Big.rawValue))
            pixels.draw(result, in: CGRect(x: 0, y: 0, width: 40, height: 20))
            let bytes = try #require(pixels.data).assumingMemoryBound(to: UInt8.self)
            let alphas = (0..<800).map { bytes[$0 * 4 + 3] }
            #expect(alphas.allSatisfy { $0 == 255 }, "\(kind.rawValue): solid to every edge, lowest \(alphas.min() ?? 0)")
            let seam = (0..<4).map { Int(bytes[(10 * 40 + 20) * 4 + $0]) }
            #expect(seam[0] > 40 && seam[1] > 40, "\(kind.rawValue): red and green blur into each other: \(seam)")
        }
    }

    /// A layer touching the canvas's edge on one side only: carried on there, spread past its other sides.
    @Test func blurSpreadsOnlyWhereTheLayerIsInsideTheCanvas() async throws {
        let session = EditorSession()
        session.createDocument(width: 80, height: 20)
        let context = try BrushRaster.context(width: 40, height: 20, mask: false)
        context.setFillColor(CGColor(srgbRed: 1, green: 1, blue: 1, alpha: 1))
        context.fill(CGRect(x: 0, y: 0, width: 40, height: 20))
        let image = try #require(context.makeImage())
        // Against the canvas's left edge, its top and bottom too; clear canvas to its right.
        session.insert(ImportedImage(image: image, thumbnail: image, name: "Block"), centeredAt: CGPoint(x: 20, y: 10))
        #expect(session.activeLayer?.transform.origin == .zero)
        session.beginFilter(.gaussianBlur)
        session.updateFilter(FilterSettings(radius: 3), preview: true)
        await session.commitFilter()
        let transform = try #require(session.activeLayer?.transform)
        #expect(transform.origin == .zero, "nothing added past the left, top or bottom: \(transform)")
        #expect(transform.size.height == 20 && transform.size.width > 40, "it spread to the right: \(transform.size)")
    }

    /// Dragging a blur bigger grows the layer to make room for it. The last preview stays on the canvas, in the place it
    /// was made for, until the preview from the grown layer replaces it — it used to be dropped, and the unblurred layer
    /// flashed up in between.
    @Test func growingABlurKeepsThePreviewUpUntilTheNextOne() async throws {
        let session = EditorSession()
        session.createDocument(width: 80, height: 60)
        let context = try BrushRaster.context(width: 40, height: 20, mask: false)
        context.setFillColor(CGColor(srgbRed: 1, green: 1, blue: 1, alpha: 1))
        context.fill(CGRect(x: 0, y: 0, width: 20, height: 20))
        let image = try #require(context.makeImage())
        session.insert(ImportedImage(image: image, thumbnail: image, name: "Half"))
        let layer = try #require(session.activeLayer)
        session.beginFilter(.gaussianBlur)
        session.updateFilter(FilterSettings(radius: 2), preview: true)
        await session.filterEdit?.previewTask?.value
        let edit = try #require(session.filterEdit)
        let first = try #require(edit.previewImage(for: layer.id))
        let firstPlace = session.displayedTransform(for: layer)
        session.updateFilter(FilterSettings(radius: 12), preview: true)
        #expect(edit.previewImage(for: layer.id) === first, "the last preview stays up while the bigger blur renders")
        #expect(session.displayedTransform(for: layer) == firstPlace, "where it was made for")
        while edit.previewTask != nil { await edit.previewTask?.value }
        let second = try #require(edit.previewImage(for: layer.id))
        #expect(second !== first)
        #expect(session.displayedTransform(for: layer).size.width > firstPlace.size.width, "the grown layer's preview, placed on it")
        session.cancelFilter()
    }

    @Test func motionBlurStreaksAlongItsAngleCounterclockwiseFromHorizontal() throws {
        // One opaque white dot in the middle of a transparent image.
        let context = try BrushRaster.context(width: 41, height: 41, mask: false)
        context.setFillColor(CGColor(srgbRed: 1, green: 1, blue: 1, alpha: 1))
        context.fill(CGRect(x: 20, y: 20, width: 1, height: 1))
        let dot = try #require(context.makeImage())
        func streak(angle: Double) throws -> (Int, Int) -> Int {
            let settings = FilterSettings(angle: angle, distance: 16)
            let image = try PixelFilter.run(FilterJob(kind: .motionBlur, image: dot, settings: settings, scale: 1,
                                                      selection: nil, mapping: .identity))
            let read = try #require(CGContext(data: nil, width: 41, height: 41, bitsPerComponent: 8, bytesPerRow: 164,
                space: CGColorSpace(name: CGColorSpace.sRGB)!,
                bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue | CGBitmapInfo.byteOrder32Big.rawValue))
            read.draw(image, in: CGRect(x: 0, y: 0, width: 41, height: 41))
            let bytes = Array(UnsafeBufferPointer(start: try #require(read.data).assumingMemoryBound(to: UInt8.self), count: 41 * 41 * 4))
            return { x, y in Int(bytes[(y * 41 + x) * 4 + 3]) } // rows top-down
        }
        let horizontal = try streak(angle: 0)
        #expect(horizontal(24, 20) > 0 && horizontal(16, 20) > 0 && horizontal(20, 24) == 0)
        let vertical = try streak(angle: 90)
        #expect(vertical(20, 24) > 0 && vertical(20, 16) > 0 && vertical(24, 20) == 0)
        // 45° runs up-right and down-left on screen, never up-left.
        let diagonal = try streak(angle: 45)
        #expect(diagonal(23, 17) > 0 && diagonal(17, 23) > 0 && diagonal(17, 17) == 0)
    }

    /// RGB Split fans a white square into a spectrum along its angle, red ahead and blue behind; Blur stretches it
    /// further; Radial leaves its center sharp.
    @Test func rgbSplitSpreadsASpectrumAlongItsAngle() throws {
        guard MetalDispersion.shared != nil else { return }
        let context = try BrushRaster.context(width: 61, height: 61, mask: false)
        context.setFillColor(CGColor(srgbRed: 1, green: 1, blue: 1, alpha: 1))
        context.fill(CGRect(x: 28, y: 28, width: 5, height: 5))
        let square = try #require(context.makeImage())
        func split(_ change: (inout FilterSettings) -> Void) throws -> (Int, Int) -> [Int] {
            var settings = FilterSettings()
            change(&settings)
            let image = try PixelFilter.run(FilterJob(kind: .rgbSplit, image: square, settings: settings, scale: 1,
                                                      selection: nil, mapping: .identity))
            let read = try #require(CGContext(data: nil, width: 61, height: 61, bitsPerComponent: 8, bytesPerRow: 244,
                space: CGColorSpace(name: CGColorSpace.sRGB)!,
                bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue | CGBitmapInfo.byteOrder32Big.rawValue))
            read.draw(image, in: CGRect(x: 0, y: 0, width: 61, height: 61))
            let bytes = Array(UnsafeBufferPointer(start: try #require(read.data).assumingMemoryBound(to: UInt8.self), count: 61 * 61 * 4))
            return { x, y in (0..<4).map { Int(bytes[(y * 61 + x) * 4 + $0]) } } // rows top-down
        }
        /// A channel added up over a run of pixels along row (or column) 30.
        func total(_ read: (Int, Int) -> [Int], _ channel: Int, _ range: ClosedRange<Int>, vertical: Bool = false) -> Int {
            range.reduce(0) { $0 + (vertical ? read(30, $1) : read($1, 30))[channel] }
        }
        let flat = try split { $0.rgbSplitDistance = 8 }
        #expect(total(flat, 0, 34...41) > total(flat, 2, 34...41) * 2, "red ahead")
        #expect(total(flat, 2, 19...26) > total(flat, 0, 19...26) * 2, "blue behind")
        #expect(total(flat, 3, 34...41) > 0 && flat(30, 40)[3] == 0, "along the angle only")
        let upright = try split { $0.rgbSplitDistance = 8; $0.rgbSplitAngle = 90 }
        #expect(total(upright, 0, 19...26, vertical: true) > total(upright, 2, 19...26, vertical: true) * 2, "red up on screen")
        let streaked = try split { $0.rgbSplitDistance = 4; $0.rgbSplitBlur = 16 }
        // Past where the split alone reaches (8 pixels from the square's edge, at 40.5), the blur's streak carries on.
        #expect(total(streaked, 3, 41...44) > 0 && total(flat, 3, 41...44) == 0, "blur stretches it further")
        let radial = try split { $0.rgbSplitDistance = 8; $0.rgbSplitRadial = true; $0.rgbSplitCenter = CGPoint(x: 30.5, y: 30.5)
                                 $0.rgbSplitReach = 30 }
        #expect(radial(30, 30) == [255, 255, 255, 255], "the center stays sharp")
        #expect(try split { $0.rgbSplitDistance = 0 }(30, 30) == [255, 255, 255, 255])
    }

    @Test func addNoiseChangesColorButNeverAlphaAndMonochromaticKeepsGrays() throws {
        // Left half opaque mid gray, right half transparent.
        let context = try BrushRaster.context(width: 32, height: 8, mask: false)
        context.setFillColor(CGColor(srgbRed: 0.5, green: 0.5, blue: 0.5, alpha: 1))
        context.fill(CGRect(x: 0, y: 0, width: 16, height: 8))
        let gray = try #require(context.makeImage())
        func pixels(_ settings: FilterSettings) throws -> [UInt8] {
            let image = try PixelFilter.run(FilterJob(kind: .addNoise, image: gray, settings: settings, scale: 1,
                                                      selection: nil, mapping: .identity, seed: 7))
            let read = try #require(CGContext(data: nil, width: 32, height: 8, bitsPerComponent: 8, bytesPerRow: 128,
                space: CGColorSpace(name: CGColorSpace.sRGB)!,
                bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue | CGBitmapInfo.byteOrder32Big.rawValue))
            read.draw(image, in: CGRect(x: 0, y: 0, width: 32, height: 8))
            return Array(UnsafeBufferPointer(start: try #require(read.data).assumingMemoryBound(to: UInt8.self), count: 32 * 8 * 4))
        }
        let offsets = Array(stride(from: 0, to: 32 * 8 * 4, by: 4))
        let opaque = offsets.filter { $0 / 4 % 32 < 16 }, clear = offsets.filter { $0 / 4 % 32 >= 16 }
        let color = try pixels(FilterSettings(amount: 10))
        #expect(try pixels(FilterSettings(amount: 10)) == color) // the same seed gives the same grain
        #expect(opaque.allSatisfy { color[$0 + 3] == 255 && (112...144).contains(Int(color[$0])) })
        #expect(Set(opaque.map { color[$0] }).count > 5)
        #expect(opaque.contains { color[$0] != color[$0 + 1] }) // color noise differs per channel
        #expect(clear.allSatisfy { color[$0] == 0 && color[$0 + 3] == 0 })
        let mono = try pixels(FilterSettings(amount: 10, gaussian: true, monochromatic: true))
        #expect(opaque.allSatisfy { mono[$0] == mono[$0 + 1] && mono[$0 + 1] == mono[$0 + 2] && mono[$0 + 3] == 255 })
    }

    @Test func removeDistortionBendsAboutTheCenterAndOnlyPincushionCorrectionOpensTheCorners() throws {
        // An opaque image with a distinct color in each quadrant.
        let context = try BrushRaster.context(width: 40, height: 30, mask: false)
        for (index, rect) in [CGRect(x: 0, y: 0, width: 20, height: 15), CGRect(x: 20, y: 0, width: 20, height: 15),
                              CGRect(x: 0, y: 15, width: 20, height: 15), CGRect(x: 20, y: 15, width: 20, height: 15)].enumerated() {
            context.setFillColor(CGColor(srgbRed: CGFloat(index) / 3, green: 0.5, blue: 1 - CGFloat(index) / 3, alpha: 1))
            context.fill(rect)
        }
        let source = try #require(context.makeImage())
        func pixels(_ distortion: Double) throws -> [UInt8] {
            let image = try PixelFilter.run(FilterJob(kind: .lensCorrection, image: source, settings: FilterSettings(distortion: distortion),
                                                      scale: 1, selection: nil, mapping: .identity))
            let read = try #require(CGContext(data: nil, width: 40, height: 30, bitsPerComponent: 8, bytesPerRow: 160,
                space: CGColorSpace(name: CGColorSpace.sRGB)!,
                bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue | CGBitmapInfo.byteOrder32Big.rawValue))
            read.draw(image, in: CGRect(x: 0, y: 0, width: 40, height: 30))
            return Array(UnsafeBufferPointer(start: try #require(read.data).assumingMemoryBound(to: UInt8.self), count: 40 * 30 * 4))
        }
        func alpha(_ bytes: [UInt8], _ x: Int, _ y: Int) -> UInt8 { bytes[(y * 40 + x) * 4 + 3] }
        let original = try pixels(0)
        #expect(original.count == 40 * 30 * 4 && (0..<(40 * 30)).allSatisfy { original[$0 * 4 + 3] == 255 })
        // Straightening barrel distortion stretches the edges outward: nothing opens up.
        let barrel = try pixels(100)
        #expect(alpha(barrel, 0, 0) == 255 && alpha(barrel, 39, 29) == 255)
        // Straightening pincushion pulls the edges in: the corners turn transparent, the middle stays put.
        let pincushion = try pixels(-100)
        #expect(alpha(pincushion, 0, 0) == 0 && alpha(pincushion, 39, 29) == 0)
        #expect(Array(pincushion[((15 * 40 + 20) * 4)..<((15 * 40 + 20) * 4 + 4)]) == Array(original[((15 * 40 + 20) * 4)..<((15 * 40 + 20) * 4 + 4)]))
    }
}
