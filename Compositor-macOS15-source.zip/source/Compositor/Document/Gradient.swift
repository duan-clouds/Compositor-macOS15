import AppKit

enum GradientStyle: String, CaseIterable, Sendable {
    case foregroundToBackground = "Foreground to Background"
    case foregroundToTransparent = "Foreground to Transparent"
}

/// Linear runs from start to end; radial is centered on the start with the end on its rim.
enum GradientShape: String, CaseIterable, Sendable {
    case linear = "Linear"
    case radial = "Radial"
}

struct GradientSettings: Equatable, Sendable {
    var shape = GradientShape.linear
    var style = GradientStyle.foregroundToTransparent
    var reversed = false
    var opacity: CGFloat = 1
}

/// An uncommitted gradient on one layer or mask. Endpoints are document pixels;
/// the raster preview lives in `raster` and never touches the document until commit.
final class GradientEdit {
    let raster: BrushStroke
    var start: CGPoint
    var end: CGPoint
    init(raster: BrushStroke, start: CGPoint) {
        self.raster = raster
        self.start = start
        end = start
    }
    var hasLine: Bool { hypot(end.x - start.x, end.y - start.y) >= 0.5 }

    /// What the gradient is filled with, as it's dragged and set.
    struct Fill: Equatable {
        let shape: GradientShape
        let start: CGPoint
        let end: CGPoint
        let colors: [CGColor]
        let opacity: CGFloat
    }
    var fill: Fill?
    /// The fill the raster's tiles hold. They're filled only when something reads them — the Core Graphics canvas, or
    /// the commit — as the GPU canvas draws the gradient itself.
    private var filled: Fill?
    func applyFill() throws {
        guard let fill, fill != filled else { return }
        try raster.fillGradient(fill.shape, from: fill.start, to: fill.end, colors: fill.colors, opacity: fill.opacity)
        filled = fill
    }
}

extension EditorSession {
    func beginGradient(at point: CGPoint) {
        guard tool == .gradient, canPaint || gradientEdit != nil, let layer = activeLayer else { return }
        // Dragging a new line replaces the pending one on the same target.
        if let edit = gradientEdit, edit.raster.layer.id == layer.id, edit.raster.isMask == isMaskSelected {
            edit.start = point
            edit.end = point
            refreshGradient()
            return
        }
        guard canPaint else { brushError = paintRefusal; return }
        finishOpacityEdit()
        do {
            gradientEdit = GradientEdit(raster: try makeRasterEdit(for: layer, growsMask: true), start: point)
            brushRevision += 1
        } catch { brushError = error.localizedDescription }
    }

    func moveGradient(start: CGPoint? = nil, end: CGPoint? = nil) {
        guard let edit = gradientEdit else { return }
        if let start { edit.start = start }
        if let end { edit.end = end }
        refreshGradient()
    }

    /// Re-renders the pending gradient from the current endpoints, settings, and palette.
    func refreshGradient() {
        guard let edit = gradientEdit else { return }
        if edit.hasLine {
            edit.fill = GradientEdit.Fill(shape: gradientSettings.shape, start: edit.start, end: edit.end,
                                          colors: gradientColors(mask: edit.raster.isMask), opacity: gradientSettings.opacity)
        }
        brushRevision += 1
    }

    func gradientColors(mask: Bool) -> [CGColor] {
        let space = mask ? CGColorSpaceCreateDeviceGray() : CGColorSpace(name: CGColorSpace.sRGB)!
        func color(_ value: PaletteColor, alpha: CGFloat) -> CGColor {
            CGColor(colorSpace: space, components: mask ? [value.red, alpha] : [value.red, value.green, value.blue, alpha])!
        }
        let foreground = paletteColor(background: false)
        let colors = gradientSettings.style == .foregroundToBackground
            ? [color(foreground, alpha: 1), color(paletteColor(background: true), alpha: 1)]
            : [color(foreground, alpha: 1), color(foreground, alpha: 0)]
        return gradientSettings.reversed ? colors.reversed() : colors
    }

    /// Ends a drag; a click without a line leaves nothing pending.
    func endGradientDrag() {
        if gradientEdit?.hasLine == false { cancelGradient() }
    }

    func cancelGradient() {
        guard gradientEdit != nil else { return }
        gradientEdit = nil
        brushRevision += 1
    }

    func commitGradient() async {
        guard let edit = gradientEdit, !isProjectBusy else { return }
        guard edit.hasLine else { cancelGradient(); return }
        do {
            try edit.applyFill()
            try await commitRasterEdit(edit.raster, name: edit.raster.isMask ? "Gradient Mask" : "Gradient")
        } catch { brushError = error.localizedDescription }
        if gradientEdit === edit { cancelGradient() }
    }

    /// Switching tools, layers, or targets applies the pending gradient, as in Photoshop.
    func resolveGradient() {
        guard gradientEdit != nil else { return }
        Task { await commitGradient() }
    }
}
