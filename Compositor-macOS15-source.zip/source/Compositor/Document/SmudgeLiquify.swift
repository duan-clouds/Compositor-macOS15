import AppKit

/// The Blur tool's modes. Smudge and Liquify push the active layer's pixels around under the brush.
/// The Brush tool's modes.
enum BrushToolMode: String, CaseIterable, Sendable {
    case paint = "Paint"
    case erase = "Erase"
}

enum BlurToolMode: String, CaseIterable, Sendable {
    case liquify = "Liquify"
    case blur = "Blur"
    case smudge = "Smudge"
}

/// A Smudge or Liquify stroke in progress. It works on the active layer as the canvas shows it, at document size,
/// changing it dab by dab; the canvas shows that working copy in place of the layer. When the stroke ends, the result
/// is painted into the layer's own pixels along the stroke's path (see `EditorSession.finishWarp`).
@MainActor final class WarpStroke {
    let layer: ImageLayer
    let mode: BlurToolMode
    let diameter: CGFloat
    let hardness: CGFloat
    let strength: CGFloat
    let width: Int
    let height: Int
    private(set) var context: CGContext
    private let pixels: UnsafeMutablePointer<UInt8>
    /// Every dab's center, for painting the result into the layer.
    private(set) var points: [CGPoint] = []
    /// The working copy on the GPU, where the dabs run when there is one (see MetalWarp).
    let gpu: MetalWarp?
    private var cpuImage: CGImage?
    /// The working copy as an image, fetched from the GPU the first time it's asked for after a dab.
    var image: CGImage? {
        guard let gpu else { return cpuImage }
        if cpuImage == nil {
            gpu.read(into: context)
            cpuImage = context.makeImage()
        }
        return cpuImage
    }
    private var last: CGPoint?
    /// Smudge: the color the brush carries, a (2r+1)² RGBA square.
    private var carried: [Float] = []
    private var scratch: [Float] = []

    /// `deep`: a 16-bit layer's 16-bit pixels (`DeepLayer`). With the GPU the working copy is then 16-bit too, so the
    /// stroke keeps the layer's precision; the CPU dabs work at 8 bits.
    init(layer: ImageLayer, image: CGImage, deep: CGImage? = nil, transform: LayerTransform, canvas: CGSize, mode: BlurToolMode,
         settings: BrushSettings, useGPU: Bool = true) throws {
        self.layer = layer
        self.mode = mode
        diameter = max(2, settings.diameter)
        hardness = min(0.98, max(0, settings.hardness))
        strength = min(1, max(0.01, settings.opacity))
        width = Int(canvas.width); height = Int(canvas.height)
        var gpu: MetalWarp?
        if useGPU, let deep, MetalWarp.pipelines != nil {
            let wide = try DeepLayer.context(width: width, height: height, hdr: DeepLayer.isHDR(deep))
            LayerRenderer.draw(deep, transform: transform, center: transform.center, in: wide)
            gpu = MetalWarp(pixels: wide)
            context = wide
        } else {
            context = try BrushRaster.context(width: width, height: height, mask: false)
            LayerRenderer.draw(image, transform: transform, center: transform.center, in: context)
            if useGPU { gpu = MetalWarp(pixels: context) }
        }
        if gpu == nil, context.bitsPerComponent != 8 {
            context = try BrushRaster.context(width: width, height: height, mask: false)
            LayerRenderer.draw(image, transform: transform, center: transform.center, in: context)
        }
        self.gpu = gpu
        guard let data = context.data else { throw ExportError.render }
        // Top-left rows: a document point's row is its y. Only the CPU dabs use these, on an 8-bit copy.
        pixels = data.bindMemory(to: UInt8.self, capacity: width * height * 4)
        cpuImage = context.makeImage()
    }

    private var radius: Int { Int((diameter / 2).rounded(.up)) }
    /// How much a dab moves pixels at a distance `u` (0 center, 1 rim) from its center.
    private func weight(_ u: Float) -> Float {
        guard u < 1 else { return 0 }
        let h = Float(hardness)
        guard u > h else { return 1 }
        let t = (1 - u) / (1 - h)
        return t * t * (3 - 2 * t)
    }

    /// Continues the stroke to `point`, dabbing along the way, then refreshes `image`.
    func append(_ point: CGPoint) {
        guard let from = last else {
            last = point
            if mode == .smudge {
                if let gpu { gpu.pickUp(at: point, radius: radius); gpu.commit() } else { pickUp(at: point) }
            }
            return
        }
        let distance = hypot(point.x - from.x, point.y - from.y)
        // Smudge drags the pixels one dab's spacing at a time and mixes them with what's there: spaced widely, each step
        // left a faint copy of what it dragged, echoes along the stroke. A pixel apart (a little more for a huge brush)
        // the steps run together into one smear, as Photoshop's does.
        let spacing = max(1, diameter * (mode == .smudge ? 0.005 : 0.025))
        guard distance >= spacing else { return }
        let steps = Int((distance / spacing).rounded(.up))
        var previous = from
        for step in 1...steps {
            let t = CGFloat(step) / CGFloat(steps)
            let next = CGPoint(x: from.x + (point.x - from.x) * t, y: from.y + (point.y - from.y) * t)
            if let gpu {
                if mode == .smudge { gpu.smudge(at: next, radius: radius, diameter: diameter, hardness: hardness, strength: strength) }
                else { gpu.push(from: previous, to: next, radius: radius, diameter: diameter, hardness: hardness, strength: strength) }
            } else if mode == .smudge { smudge(at: next) } else { push(from: previous, to: next) }
            points.append(next)
            previous = next
        }
        last = point
        if let gpu {
            gpu.commit()
            cpuImage = nil
        } else {
            cpuImage = context.makeImage()
        }
    }

    private func pickUp(at center: CGPoint) {
        let r = radius, side = 2 * r + 1
        carried = [Float](repeating: 0, count: side * side * 4)
        let cx = Int(center.x.rounded()), cy = Int(center.y.rounded())
        for dy in -r...r {
            let y = cy + dy
            guard y >= 0, y < height else { continue }
            for dx in -r...r {
                let x = cx + dx
                guard x >= 0, x < width else { continue }
                let p = (y * width + x) * 4, c = ((dy + r) * side + dx + r) * 4
                for k in 0..<4 { carried[c + k] = Float(pixels[p + k]) }
            }
        }
    }

    private func smudge(at center: CGPoint) {
        let r = radius, side = 2 * r + 1
        let cx = Int(center.x.rounded()), cy = Int(center.y.rounded())
        let keep = Float(strength), invR = 1 / Float(diameter / 2)
        for dy in -r...r {
            let y = cy + dy
            guard y >= 0, y < height else { continue }
            for dx in -r...r {
                let x = cx + dx
                guard x >= 0, x < width else { continue }
                let w = weight(Float(dx * dx + dy * dy).squareRoot() * invR)
                guard w > 0 else { continue }
                let p = (y * width + x) * 4, c = ((dy + r) * side + dx + r) * 4
                for k in 0..<4 {
                    let under = Float(pixels[p + k])
                    // What was under the brush at the last dab, laid down here at the smudge's strength, as Photoshop
                    // does: all of it drags the pixels along; less mixes them with what's here, softening the trail.
                    let painted = under + (carried[c + k] - under) * w * keep
                    pixels[p + k] = UInt8(max(0, min(255, painted.rounded())))
                    // The brush then carries what it just left, and nothing older: holding on to what it picked up
                    // at the start stamped it again at every dab, a trail of ghost copies.
                    carried[c + k] = painted
                }
            }
        }
    }

    /// Forward warp: pixels under the brush move with it, most at its center, fading to none at its rim.
    private func push(from a: CGPoint, to b: CGPoint) {
        let r = radius
        let move = SIMD2<Float>(Float(b.x - a.x), Float(b.y - a.y)) * Float(strength)
        let margin = Int(ceil(max(abs(move.x), abs(move.y)))) + 2
        let cx = Int(b.x.rounded()), cy = Int(b.y.rounded())
        // A copy of the area as it was before this dab, which the dab samples from.
        let x0 = max(0, cx - r - margin), x1 = min(width - 1, cx + r + margin)
        let y0 = max(0, cy - r - margin), y1 = min(height - 1, cy + r + margin)
        guard x0 <= x1, y0 <= y1 else { return }
        let cw = x1 - x0 + 1, ch = y1 - y0 + 1
        if scratch.count < cw * ch * 4 { scratch = [Float](repeating: 0, count: cw * ch * 4) }
        for y in 0..<ch {
            for x in 0..<cw {
                let p = ((y + y0) * width + x + x0) * 4, s = (y * cw + x) * 4
                for k in 0..<4 { scratch[s + k] = Float(pixels[p + k]) }
            }
        }
        let invR = 1 / Float(diameter / 2)
        for dy in -r...r {
            let y = cy + dy
            guard y >= y0, y <= y1 else { continue }
            for dx in -r...r {
                let x = cx + dx
                guard x >= x0, x <= x1 else { continue }
                let w = weight(Float(dx * dx + dy * dy).squareRoot() * invR)
                guard w > 0 else { continue }
                // Bilinear sample of the old pixels, from behind the brush's travel.
                let sx = min(Float(cw - 1), max(0, Float(x - x0) - move.x * w))
                let sy = min(Float(ch - 1), max(0, Float(y - y0) - move.y * w))
                let ix = min(cw - 2, Int(sx)), iy = min(ch - 2, Int(sy))
                guard ix >= 0, iy >= 0 else { continue }
                let fx = sx - Float(ix), fy = sy - Float(iy)
                let p = (y * width + x) * 4
                let s00 = (iy * cw + ix) * 4, s10 = s00 + 4, s01 = s00 + cw * 4, s11 = s01 + 4
                for k in 0..<4 {
                    let top = scratch[s00 + k] + (scratch[s10 + k] - scratch[s00 + k]) * fx
                    let bottom = scratch[s01 + k] + (scratch[s11 + k] - scratch[s01 + k]) * fx
                    pixels[p + k] = UInt8(max(0, min(255, (top + (bottom - top) * fy).rounded())))
                }
            }
        }
    }
}

extension EditorSession {
    func beginWarp(at point: CGPoint) {
        guard canPaint, !isMaskSelected, let active = activeLayer, let document else {
            brushError = isMaskSelected ? "Smudge and Liquify work on a layer's pixels, not its mask." : paintRefusal
            return
        }
        pauseGIFForEditing(for: active.id)
        let layer = pixelEditingLayer(for: active)
        guard let image = layer.asset?.image else { return }
        finishOpacityEdit()
        do {
            let stroke = try WarpStroke(layer: layer, image: image, deep: try layer.asset.flatMap { try DeepLayer.flattened($0) },
                                        transform: displayedTransform(for: layer),
                                        canvas: document.size, mode: blurMode, settings: brushSettings)
            stroke.append(point)
            warpStroke = stroke
            lastBrushPoint = (point, layer.id, false)
            brushRevision += 1
        } catch { brushError = error.localizedDescription }
    }

    /// Paints the finished Smudge or Liquify result into the layer's pixels along the stroke, as one undo step.
    func finishWarp() {
        guard let warp = warpStroke else { return }
        warpStroke = nil
        brushRevision += 1
        guard !warp.points.isEmpty, let result = warp.image,
              let current = document?.layers.first(where: { $0.id == warp.layer.id }),
              pixelEditTargetMatches(current, original: warp.layer) else { return }
        do {
            var settings = brushSettings
            // A hard tip a little wider than the brush covers everything the stroke moved.
            settings.diameter = warp.diameter + 4
            settings.hardness = 1
            settings.opacity = 1
            let stroke = try makeRasterEdit(for: current, settings: settings)
            stroke.clone = (result, CGRect(x: 0, y: 0, width: result.width, height: result.height), false)
            // A 16-bit working copy goes into the layer's 16-bit pixels.
            if result.bitsPerComponent == 16 { stroke.deepClone = stroke.clone }
            stroke.replacesWithClone = true
            stroke.editName = warp.mode.rawValue
            // The tip is solid and a little wider than the brush, so a point every twentieth of its width covers what
            // every dab did: a big brush on a big canvas lays thousands of dabs, and replaying each one stalled the release.
            let spacing = max(1, warp.diameter * 0.05)
            var kept: CGPoint?
            for (index, point) in warp.points.enumerated() {
                if let kept, index < warp.points.count - 1, hypot(point.x - kept.x, point.y - kept.y) < spacing { continue }
                try stroke.append(point)
                kept = point
            }
            try stroke.flush()
            if !stroke.patches.isEmpty { try commitPaintSnapshot(stroke) }
        } catch { brushError = error.localizedDescription }
    }
}
