import AppKit
import Observation
import UniformTypeIdentifiers

@MainActor
final class ProjectTab: Identifiable {
    let id = UUID()
    let session: EditorSession
    let controller: ProjectController
    /// Shown until the project is saved: Untitled, the opened file's name, or a Photoshop artboard's.
    var defaultName: String
    var title: String { session.projectURL?.deletingPathExtension().lastPathComponent ?? defaultName }
    init(name: String) {
        defaultName = name
        session = EditorSession()
        controller = ProjectController(session: session)
    }
}

@MainActor @Observable
final class ProjectWorkspace {
    private(set) var tabs: [ProjectTab] = []
    private(set) var selectedID: UUID
    var isManaging = false
    @ObservationIgnored weak var window: NSWindow?
    var current: ProjectTab { tabs.first { $0.id == selectedID } ?? tabs[0] }
    var canSwitch: Bool {
        let s = current.session
        return !isManaging && s.canStartProjectOperation && s.hueSaturation == nil && s.filterEdit == nil
            && s.gradientEdit == nil && s.pixelMove == nil && s.colorPicker == nil
    }
    init() {
        let first = ProjectTab(name: "Untitled")
        defer { attach(first) }
        first.session.skipsInitialClipboardCanvasSize = true
        tabs = [first]; selectedID = first.id
        first.controller.workspace = self
    }
    /// A new tab's name: "Untitled" if no tab shows it, otherwise the lowest "Untitled N" free, as Finder and Safari
    /// number them. Counting up for ever, closing the last tab made Untitled 2, then 3, and on.
    private var freeUntitledName: String {
        let taken = Set(tabs.map(\.title))
        guard taken.contains("Untitled") else { return "Untitled" }
        return (2...).lazy.map { "Untitled \($0)" }.first { !taken.contains($0) }!
    }
    /// Whether a tab can close: not the only one while it's empty, the blank start it would only be replaced with.
    func canClose(_ tab: ProjectTab) -> Bool {
        !(tabs.count == 1 && tab.session.document == nil && tab.session.projectURL == nil)
    }
    @discardableResult
    func addTab(reuseEmpty: Bool = true) -> ProjectTab {
        if reuseEmpty, tabs.count == 1, current.session.document == nil { return current }
        let tab = ProjectTab(name: freeUntitledName)
        tab.controller.workspace = self; tab.controller.window = window
        attach(tab)
        tabs.append(tab); selectedID = tab.id
        return tab
    }
    /// Gives `tab` the way to open a Photoshop file's artboards, each as a document in a tab of its own: the first in
    /// `tab` while it's still empty, the rest in new tabs named for them.
    private func attach(_ tab: ProjectTab) {
        tab.session.opensArtboard = { [weak self, weak tab] document, name in
            guard let self, let tab else { return }
            let target: ProjectTab
            if tab.session.document == nil, tabs.contains(where: { $0 === tab }) {
                target = tab
                target.defaultName = name
            } else {
                target = ProjectTab(name: name)
                target.controller.workspace = self; target.controller.window = window
                attach(target)
                tabs.append(target)
            }
            selectedID = target.id
            await target.session.importArtboard(document, named: name)
        }
    }

    /// Reorders a tab by dragging it in the strip. Chrome, not a document edit, so it never touches undo.
    /// `index` is where the tab should land in the final order, clamped to the array's bounds.
    func moveTab(_ id: UUID, to index: Int) {
        guard let from = tabs.firstIndex(where: { $0.id == id }) else { return }
        let target = min(max(0, index), tabs.count - 1)
        guard target != from else { return }
        let tab = tabs.remove(at: from)
        tabs.insert(tab, at: target)
    }
    func select(_ id: UUID) {
        guard id != selectedID, canSwitch, tabs.contains(where: { $0.id == id }) else { return }
        current.session.commitTransform()
        selectedID = id
        current.controller.window = window
        current.controller.resumeExternalChangeCheck()
    }
    func newCanvas() {
        guard canSwitch else { return }
        current.session.commitTransform()
        _ = addTab(reuseEmpty: false)
    }
    @discardableResult
    func open(_ suppliedURL: URL? = nil) async -> Bool {
        guard canSwitch else { return false }
        isManaging = true
        defer { isManaging = false }
        var urls = suppliedURL.map { [$0] } ?? []
        if urls.isEmpty {
            let panel = NSOpenPanel()
            panel.allowedContentTypes = [.compositorProject]
            panel.allowsMultipleSelection = true
            panel.treatsFilePackagesAsDirectories = false
            let response = if let window { await panel.beginSheetModal(for: window) } else { await panel.begin() }
            guard response == .OK else { return false }
            urls = panel.urls
        }
        var opened = false
        for url in urls { opened = await loadProject(url) || opened }
        return opened
    }
    private func loadProject(_ url: URL) async -> Bool {
        if let existing = tabs.first(where: { $0.session.projectURL?.resolvingSymlinksInPath() == url.resolvingSymlinksInPath() }) {
            selectedID = existing.id; return true
        }
        // Load into an unattached session, so a failed open never leaves a broken tab.
        let tab = ProjectTab(name: url.deletingPathExtension().lastPathComponent)
        attach(tab)
        tab.controller.window = window
        guard await tab.controller.open(url) else { return false }
        if tabs.count == 1, current.session.document == nil { tabs.removeAll() }
        tab.controller.workspace = self; tabs.append(tab); selectedID = tab.id
        return true
    }
    func close(_ id: UUID) async {
        guard canSwitch, let tab = tabs.first(where: { $0.id == id }), canClose(tab) else { return }
        isManaging = true
        defer { isManaging = false }
        tab.controller.window = window
        guard await tab.controller.confirmQuit() else { return }
        removeTab(id)
    }
    func removeTab(_ id: UUID) {
        guard let index = tabs.firstIndex(where: { $0.id == id }) else { return }
        tabs.remove(at: index)
        if tabs.isEmpty { _ = addTab(reuseEmpty: false) }
        else if selectedID == id { selectedID = tabs[min(index, tabs.count-1)].id }
    }
    /// The order Quit (and closing the window) asks about unsaved projects: the tab on screen first,
    /// then the rest left to right, so it never jumps to another project before the one you're viewing.
    var quitOrder: [ProjectTab] { [current] + tabs.filter { $0.id != current.id } }
    private func finishTextEditing() -> Bool {
        for tab in quitOrder where tab.session.textDraft != nil {
            guard tab.session.finishText() else { return false }
        }
        return true
    }
    /// Readies the project on screen for quitting or closing, rather than refusing over what's in progress. Edits on
    /// the canvas (a gradient waiting for Apply, pixels being moved) are applied, as switching tools does; an open dialog
    /// (a filter, Levels, Hue/Saturation, the color picker…) is cancelled, as its Cancel button would, so nothing is
    /// applied that wasn't OK'd.
    func settlePendingEdits() async {
        let session = current.session
        if session.gradientEdit != nil { await session.commitGradient() }
        if session.pixelMove != nil { await session.finishPixelMove() }
        session.cancelFilter()
        session.cancelHueSaturation()
        session.cancelLevels()
        session.finishAdjustmentEditing(commit: false)
        session.cancelColorRange()
        session.selectionAmountOperation = nil
        if session.colorPicker != nil { session.closeColorPicker(commit: false) }
    }
    func confirmQuit() async -> Bool {
        guard !isManaging, finishTextEditing() else { return false }
        await settlePendingEdits()
        guard canSwitch else { NSSound.beep(); return false }
        isManaging = true; defer { isManaging = false }
        for tab in quitOrder {
            selectedID = tab.id; tab.controller.window = window
            guard await tab.controller.confirmQuit() else { return false }
        }
        return true
    }
    func closeWindow(_ window: NSWindow) async {
        guard await confirmQuit() else { return }
        tabs.removeAll(); _ = addTab(reuseEmpty: false)
        window.close()
    }

    /// Capture the destination before asynchronous provider loading. Dock/new-tab
    /// drops create one project per image; existing-tab drops add image layers.
    func receive(_ urls: [URL], into destination: UUID? = nil, at point: CGPoint? = nil) async {
        let files = urls.map { ($0, $0.startAccessingSecurityScopedResource()) }
        defer { for (url, scoped) in files where scoped { url.stopAccessingSecurityScopedResource() } }
        while !canSwitch {
            if Task.isCancelled { return }
            try? await Task.sleep(for: .milliseconds(30))
        }
        isManaging = true; defer { isManaging = false }
        for url in urls {
            if url.pathExtension.lowercased() == "comp" { _ = await loadProject(url); continue }
            let tab: ProjectTab
            if let destination {
                guard let existing = tabs.first(where: { $0.id == destination }) else { continue }
                tab = existing
            } else { tab = addTab() }
            selectedID = tab.id
            await tab.session.importImages([url], at: point)
        }
    }
    func receiveProviders(_ providers: [NSItemProvider], into destination: UUID? = nil, at point: CGPoint? = nil) async {
        for provider in providers {
            if provider.hasItemConformingToTypeIdentifier(Self.layerType) {
                let data: Data? = await withCheckedContinuation { continuation in
                    provider.loadDataRepresentation(forTypeIdentifier: Self.layerType) { data, _ in continuation.resume(returning: data) }
                }
                if let data, let value = String(data: data, encoding: .utf8), let id = UUID(uuidString: value.trimmingCharacters(in: .whitespacesAndNewlines)) {
                    await copyLayer(id, into: destination, at: point)
                }
            } else {
                await ImageFileDrop.importProviders([provider], into: current.session, at: point, workspace: self, destination: destination)
            }
        }
    }
    static let layerType = "com.compositor.layer-row"
    /// Cmd-V with a whole layer copied: pastes it complete — a copy above it in its own project, or brought over as
    /// dragging it onto this tab does. False when there is none, and Paste goes on with pixels.
    func pasteCopiedLayer() -> Bool {
        let count = EditorSession.pasteboard.changeCount
        guard let source = tabs.first(where: { $0.session.copiedLayer?.changeCount == count }),
              let copied = source.session.copiedLayer?.ids, let layers = source.session.document?.layers else { return false }
        let ids = copied.filter { id in layers.contains { $0.id == id } }
        guard !ids.isEmpty else { return false }
        if source.id == selectedID {
            guard source.session.canEditLayers else { return false }
            source.session.duplicateLayers(ids, editName: "Paste")
            return true
        }
        let destination = selectedID
        Task { await copyLayers(ids, into: destination) }
        return true
    }
    func copyLayer(_ id: UUID, into destination: UUID?, at point: CGPoint? = nil) async {
        await copyLayers([id], into: destination, at: point)
    }
    /// Copies layers (folders with all they hold) into another project, or a new one, as one undo step there. Several
    /// keep where they sit relative to each other, centered on `point` or the canvas as a whole.
    func copyLayers(_ ids: [UUID], into destination: UUID?, at point: CGPoint? = nil) async {
        guard let id = ids.first, canSwitch, let sourceTab = tabs.first(where: { $0.session.document?.layers.contains(where: { $0.id == id }) == true }),
              sourceTab.session.canEditLayers, let snapshot = sourceTab.session.projectSnapshot(),
              let sourceDocument = sourceTab.session.document else { return }
        if let destination, destination == sourceTab.id { return }
        let target: ProjectTab
        if let destination {
            guard let existing = tabs.first(where: { $0.id == destination }), existing.session.canStartProjectOperation else { return }
            target = existing
        } else { target = addTab(reuseEmpty: false) }
        guard target.session.document == nil || target.session.canEditLayers else { return }
        let included = ids.reduce(into: Set(ids)) { $0.formUnion(sourceTab.session.descendantIDs(of: $1)) }
        var copied = sourceDocument.layers.filter { included.contains($0.id) }.map { layer in
            var copy = layer
            copy.asset = snapshot.images[layer.id]
            copy.gifAnimation = snapshot.animations[layer.id]
            return copy
        }
        let used = target.session.document?.layers.reduce(0) { $0 + ($1.asset.map { $0.image.width * $0.image.height } ?? 0) } ?? 0
        let added = copied.reduce(0) { $0 + ($1.asset.map { $0.image.width * $0.image.height } ?? 0) }
        guard used + added <= DocumentLimits.documentPixelBudget else { target.session.importError = "The copied layers exceed this project’s \(DocumentLimits.documentBudgetMegapixels)-megapixel limit."; return }
        guard target.session.canRetainGIFSources(in: (target.session.document?.layers ?? []) + copied) else {
            target.session.importError = "The copied GIFs exceed this project’s animation memory limit."
            return
        }
        isManaging = true
        sourceTab.session.isProjectBusy = true
        target.session.isProjectBusy = true
        defer {
            isManaging = false
            sourceTab.session.isProjectBusy = false
            target.session.isProjectBusy = false
        }
        do {
            for i in copied.indices where copied[i].maskSourceID.map({ !included.contains($0) }) == true {
                if copied[i].adjustment != nil { copied[i].maskSourceID = nil; continue }
                let layerID = copied[i].id
                copied[i].asset = try await Task.detached(priority: .userInitiated) { try LiveMaskBaker.bake(snapshot, target: layerID) }.value
                if copied[i].gifAnimation != nil {
                    // An omitted live-mask source is baked into the displayed frame; keep that raster result
                    // and its current mask, rather than replacing it with an unclipped frame during playback.
                    if let record = snapshot.manifest.layers.first(where: { $0.id == layerID }) {
                        copied[i].mask = snapshot.mask(for: record)
                    }
                    copied[i].gifAnimation = nil
                }
                copied[i].maskSourceID = nil
            }
            let mapping = Dictionary(uniqueKeysWithValues: copied.map { ($0.id, UUID()) })
            let pictured = copied.filter { !$0.isGroup }.map { CGRect(origin: $0.transform.origin, size: $0.transform.size) }
            // A new project is the size of the pixels dragged in (turned as they're shown), not of the canvas they
            // came from; layers with none of their own (adjustments, blank layers) don't count.
            let drawn = copied.filter { !$0.isGroup && $0.adjustment == nil && ($0.asset != nil || $0.text != nil) }.map { layer in
                let corners = [CGPoint(x: 0, y: 0), CGPoint(x: 1, y: 0), CGPoint(x: 0, y: 1), CGPoint(x: 1, y: 1)].map(layer.transform.point)
                let xs = corners.map(\.x), ys = corners.map(\.y)
                return CGRect(x: xs.min()!, y: ys.min()!, width: xs.max()! - xs.min()!, height: ys.max()! - ys.min()!)
            }
            let fitted = target.session.document == nil && !drawn.isEmpty
                ? drawn.dropFirst().reduce(drawn[0]) { $0.union($1) }.integral : nil
            let size = target.session.document?.size ?? fitted.map {
                CGSize(width: min(CGFloat(DocumentLimits.maxSide), $0.width), height: min(CGFloat(DocumentLimits.maxSide), $0.height))
            } ?? sourceDocument.size
            let anchor = fitted.map { CGPoint(x: $0.midX, y: $0.midY) } ?? (ids.count == 1 || pictured.isEmpty
                ? copied.first(where: { $0.id == id })?.transform.center ?? CGPoint(x: sourceDocument.size.width/2, y: sourceDocument.size.height/2)
                : { let r = pictured.dropFirst().reduce(pictured[0]) { $0.union($1) }; return CGPoint(x: r.midX, y: r.midY) }())
            let center = fitted == nil ? point ?? CGPoint(x: size.width/2, y: size.height/2) : CGPoint(x: size.width/2, y: size.height/2)
            let layers = copied.map { layer -> ImageLayer in
                var transform = layer.transform
                transform.origin.x += center.x-anchor.x; transform.origin.y += center.y-anchor.y
                var mask = layer.mask
                mask?.placement?.origin.x += center.x-anchor.x; mask?.placement?.origin.y += center.y-anchor.y
                return ImageLayer(id: mapping[layer.id]!, asset: layer.asset, name: layer.name, isVisible: layer.isVisible,
                    transform: transform, parentID: layer.parentID.flatMap { mapping[$0] }, isGroup: layer.isGroup,
                    opacity: layer.opacity, blendMode: layer.blendMode, mask: mask, maskSourceID: layer.maskSourceID.flatMap { mapping[$0] }, adjustment: layer.adjustment, shape: layer.shape, effects: layer.effects, text: layer.text,
                    gifAnimation: layer.gifAnimation)
            }
            target.session.isProjectBusy = false
            target.session.beginEdit("Copy Layers from Project")
            if target.session.document == nil { target.session.createDocument(width: Int(size.width), height: Int(size.height)) }
            target.session.document?.layers.append(contentsOf: layers)
            target.session.activeLayerID = mapping[id]
            target.session.selectedLayerIDs = Set(ids.compactMap { mapping[$0] })
            target.session.endEdit()
            selectedID = target.id
        } catch { target.session.importError = error.localizedDescription }
    }
}
